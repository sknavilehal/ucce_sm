export = ldBar;
declare class ldBar {
  constructor(element: any, options: object);
  set(value: number): void;
}
